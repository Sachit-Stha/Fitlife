package com.atilmohamine.fitlife

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlin.math.sqrt

class WorkoutListActivity : AppCompatActivity(),
    WorkoutAdapter.WorkoutListener,
    SensorEventListener {

    private lateinit var db: MyDatabaseHelper
    private lateinit var session: SessionManager
    private lateinit var adapter: WorkoutAdapter
    private var userId: Int = -1

    // Sensors (Shake Reset)
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private val shakeThreshold = 13f
    private var lastShakeTime = 0L

    private var lastX = 0f
    private var lastY = 0f
    private var lastZ = 0f
    private var firstRead = true

    // SMS Permission
    private val SMS_PERMISSION = Manifest.permission.SEND_SMS
    private val SMS_REQUEST_CODE = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workout_list)

        requestSmsPermission()
        checkSession()
        initDatabase()
        initUI()
        setupSwipeGestures()
        setupSensors()
    }

    // --------------------------------------------------
    // INITIAL SETUP
    // --------------------------------------------------

    private fun requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, SMS_PERMISSION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(SMS_PERMISSION),
                SMS_REQUEST_CODE
            )
        }
    }

    private fun checkSession() {
        session = SessionManager(this)
        userId = session.getUserId() ?: run {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
    }

    private fun initDatabase() {
        db = MyDatabaseHelper(this)
    }

    private fun initUI() {
        val rv = findViewById<RecyclerView>(R.id.rv_workouts)
        val fabAdd = findViewById<FloatingActionButton>(R.id.fab_add)
        val btnLogout = findViewById<ImageButton>(R.id.btn_logout)

        adapter = WorkoutAdapter(mutableListOf(), this)

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        loadWorkouts()

        fabAdd.setOnClickListener {
            startActivity(
                Intent(this, AddEditWorkoutActivity::class.java)
                    .putExtra("user_id", userId)
            )
        }

        btnLogout.setOnClickListener {
            session.clearSession()
            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    // --------------------------------------------------
    // SWIPE ACTIONS
    // --------------------------------------------------

    private fun setupSwipeGestures() {
        val swipeGesture = object : SwipeGesture(this) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val workout = adapter.getItem(viewHolder.adapterPosition) ?: return

                when (direction) {
                    ItemTouchHelper.LEFT -> {
                        db.deleteWorkout(workout.id)
                        loadWorkouts()
                        Toast.makeText(
                            this@WorkoutListActivity,
                            "Workout deleted",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    ItemTouchHelper.RIGHT -> {
                        workout.isDone = true
                        db.updateWorkout(workout)

                        adapter.notifyItemChanged(viewHolder.adapterPosition)

                        Toast.makeText(
                            this@WorkoutListActivity,
                            "Workout completed",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }
            }
        }

        ItemTouchHelper(swipeGesture)
            .attachToRecyclerView(findViewById(R.id.rv_workouts))
    }

    // --------------------------------------------------
    // SENSOR SETUP
    // --------------------------------------------------

    private fun setupSensors() {
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    }

    override fun onResume() {
        super.onResume()
        loadWorkouts()
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    // --------------------------------------------------
    // DATA
    // --------------------------------------------------

    private fun loadWorkouts() {
        adapter.setItems(db.getWorkoutsForUser(userId))
    }

    // --------------------------------------------------
    // ADAPTER CALLBACKS
    // --------------------------------------------------

    override fun onEdit(workout: Workout) {
        startActivity(
            Intent(this, AddEditWorkoutActivity::class.java)
                .putExtra("workout_id", workout.id)
                .putExtra("user_id", userId)
        )
    }

    override fun onDelete(workout: Workout) {
        db.deleteWorkout(workout.id)
        loadWorkouts()
        Toast.makeText(this, "Workout deleted", Toast.LENGTH_SHORT).show()
    }

    override fun onToggleDone(workout: Workout, isDone: Boolean) {
        workout.isDone = isDone
        db.updateWorkout(workout)
    }

    override fun onSendSMS(workout: Workout) {
        val message = """
            🏋️ FitLife Workout
            ${workout.title}
            Sets: ${workout.sets}
            Reps: ${workout.reps}
            Notes: ${workout.notes ?: "None"}
        """.trimIndent()

        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("sms:")
            putExtra("sms_body", message)
        }

        startActivity(intent)
    }

    // --------------------------------------------------
    // SHAKE DETECTION
    // --------------------------------------------------

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_ACCELEROMETER) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        if (firstRead) {
            lastX = x; lastY = y; lastZ = z
            firstRead = false
            return
        }

        val delta = sqrt(
            (x - lastX) * (x - lastX) +
                    (y - lastY) * (y - lastY) +
                    (z - lastZ) * (z - lastZ)
        )

        val now = System.currentTimeMillis()
        if (delta > shakeThreshold && now - lastShakeTime > 1200) {
            lastShakeTime = now
            resetAllWorkouts()
        }

        lastX = x; lastY = y; lastZ = z
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun resetAllWorkouts() {
        db.getWorkoutsForUser(userId).forEach {
            it.isDone = false
            db.updateWorkout(it)
        }
        loadWorkouts()
        Toast.makeText(this, "All workouts reset!", Toast.LENGTH_SHORT).show()
    }

    // --------------------------------------------------
    // PERMISSIONS
    // --------------------------------------------------

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_REQUEST_CODE) {
            Toast.makeText(
                this,
                if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED)
                    "SMS permission granted"
                else
                    "SMS permission denied",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
