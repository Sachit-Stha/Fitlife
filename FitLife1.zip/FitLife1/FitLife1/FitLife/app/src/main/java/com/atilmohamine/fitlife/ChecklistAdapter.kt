package com.atilmohamine.fitlife

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChecklistAdapter(
    private val items: MutableList<ChecklistItem>,
    private val onCheckedChange: (ChecklistItem, Boolean) -> Unit
) : RecyclerView.Adapter<ChecklistAdapter.ViewHolder>() {

    init {
        setHasStableIds(true) // ✅ smoother swipe & updates
    }

    // ==========================
    // VIEW HOLDER
    // ==========================
    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvSetsReps: TextView = view.findViewById(R.id.tvSetsReps)
        val cbDone: CheckBox = view.findViewById(R.id.cbDone)
    }

    // ==========================
    // ADAPTER CORE
    // ==========================
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_checklist, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun getItemId(position: Int): Long {
        return items[position].id.toLong()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        holder.tvTitle.text = item.title
        holder.tvSetsReps.text = "${item.sets} sets × ${item.reps} reps"

        // --------------------------------
        // STRIKE ONLY TITLE WHEN DONE
        // --------------------------------
        if (item.isDone) {
            holder.tvTitle.paintFlags =
                holder.tvTitle.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            holder.tvTitle.alpha = 0.6f
        } else {
            holder.tvTitle.paintFlags =
                holder.tvTitle.paintFlags and android.graphics.Paint.STRIKE_THRU_TEXT_FLAG.inv()
            holder.tvTitle.alpha = 1f
        }

        // Prevent recycle issues
        holder.cbDone.setOnCheckedChangeListener(null)
        holder.cbDone.isChecked = item.isDone

        holder.cbDone.setOnCheckedChangeListener { _, isChecked ->
            if (item.isDone != isChecked) {
                item.isDone = isChecked
                onCheckedChange(item, isChecked)
                notifyItemChanged(position)
            }
        }
    }


    // ==========================
    // SWIPE SUPPORT
    // ==========================
    fun getItem(position: Int): ChecklistItem? =
        if (position in items.indices) items[position] else null

    fun removeItem(position: Int) {
        if (position in items.indices) {
            items.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, items.size)
        }
    }

    // ==========================
    // DATA UPDATE
    // ==========================
    fun updateItem(updated: ChecklistItem) {
        val index = items.indexOfFirst { it.id == updated.id }
        if (index != -1) {
            items[index] = updated
            notifyItemChanged(index)
        }
    }

    fun setItems(newItems: List<ChecklistItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
