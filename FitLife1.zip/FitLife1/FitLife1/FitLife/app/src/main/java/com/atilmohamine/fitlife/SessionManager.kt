package com.atilmohamine.fitlife

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("fitlife_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USERNAME = "username"
        private const val KEY_EMAIL = "email"
        private const val KEY_JOINED = "joined"
        private const val KEY_PROFILE_IMAGE = "profile_image"
    }

    // ==========================
    // SAVE FULL USER SESSION
    // ==========================
    fun saveUserSession(
        userId: Int,
        username: String,
        email: String,
        joinedAt: Long
    ) {
        prefs.edit().apply {
            putInt(KEY_USER_ID, userId)
            putString(KEY_USERNAME, username)
            putString(KEY_EMAIL, email)
            putLong(KEY_JOINED, joinedAt)
            apply()
        }
    }

    // ==========================
    // USER ID
    // ==========================
    fun saveUserId(id: Int) {
        prefs.edit().putInt(KEY_USER_ID, id).apply()
    }

    fun getUserId(): Int? {
        val id = prefs.getInt(KEY_USER_ID, -1)
        return if (id == -1) null else id
    }

    // ==========================
    // PROFILE DATA
    // ==========================
    fun getUsername(): String? {
        return prefs.getString(KEY_USERNAME, null)
    }

    fun getEmail(): String? {
        return prefs.getString(KEY_EMAIL, null)
    }

    fun getJoinedDate(): Long {
        return prefs.getLong(KEY_JOINED, 0L)
    }

    // ==========================
    // PROFILE IMAGE
    // ==========================
    fun saveProfileImage(uri: String) {
        prefs.edit().putString(KEY_PROFILE_IMAGE, uri).apply()
    }

    fun getProfileImage(): String? {
        return prefs.getString(KEY_PROFILE_IMAGE, null)
    }

    // ==========================
    // SESSION STATE
    // ==========================
    fun isLoggedIn(): Boolean {
        return getUserId() != null
    }

    // ==========================
    // LOGOUT
    // ==========================
    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
