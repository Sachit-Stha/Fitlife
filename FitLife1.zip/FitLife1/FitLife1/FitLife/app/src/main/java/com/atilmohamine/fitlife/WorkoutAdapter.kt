package com.atilmohamine.fitlife

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WorkoutAdapter(
    private val items: MutableList<Workout>,
    private val listener: WorkoutListener
) : RecyclerView.Adapter<WorkoutAdapter.WorkoutViewHolder>() {

    interface WorkoutListener {
        fun onEdit(workout: Workout)
        fun onDelete(workout: Workout)
        fun onToggleDone(workout: Workout, isDone: Boolean)
        fun onSendSMS(workout: Workout)
    }

    init {
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long {
        return items[position].id.toLong()
    }

    fun getItem(position: Int): Workout? =
        items.getOrNull(position)

    fun setItems(newItems: List<Workout>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class WorkoutViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.tv_title)
        val tvDetails: TextView = itemView.findViewById(R.id.tv_details)
        val cbDone: CheckBox = itemView.findViewById(R.id.cb_done)
        val btnSms: ImageButton = itemView.findViewById(R.id.btn_sms)
        val btnEdit: ImageButton = itemView.findViewById(R.id.btn_edit)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkoutViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_workout, parent, false)
        return WorkoutViewHolder(view)
    }

    override fun onBindViewHolder(holder: WorkoutViewHolder, position: Int) {
        val workout = items[position]

        // Title & details
        holder.tvTitle.text = workout.title
        holder.tvDetails.text = "${workout.sets} sets × ${workout.reps} reps"

        // Reset checkbox listener
        holder.cbDone.setOnCheckedChangeListener(null)
        holder.cbDone.isChecked = workout.isDone

        // Premium completed effect
        if (workout.isDone) {
            holder.tvTitle.paintFlags =
                holder.tvTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            holder.tvTitle.alpha = 0.6f
            holder.tvDetails.alpha = 0.6f
        } else {
            holder.tvTitle.paintFlags =
                holder.tvTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            holder.tvTitle.alpha = 1f
            holder.tvDetails.alpha = 1f
        }

        // Checkbox toggle
        holder.cbDone.setOnCheckedChangeListener { _, isChecked ->
            if (workout.isDone != isChecked) {
                workout.isDone = isChecked
                listener.onToggleDone(workout, isChecked)
                notifyItemChanged(position)
            }
        }

        // SMS
        holder.btnSms.setOnClickListener {
            listener.onSendSMS(workout)
        }

        // Edit
        holder.btnEdit.setOnClickListener {
            listener.onEdit(workout)
        }

        // Delete
        holder.btnDelete.setOnClickListener {
            listener.onDelete(workout)
        }
    }

    override fun getItemCount(): Int = items.size
}
