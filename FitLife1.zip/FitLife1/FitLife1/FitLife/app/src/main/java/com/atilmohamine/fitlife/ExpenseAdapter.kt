package com.atilmohamine.fitlife

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ExpenseAdapter(
    private val expenses: MutableList<Expense>
) : RecyclerView.Adapter<ExpenseAdapter.ViewHolder>() {

    init {
        setHasStableIds(true) // ✅ improves swipe & animations
    }

    // ==========================
    // VIEW HOLDER
    // ==========================
    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvExpenseTitle)
        val tvAmount: TextView = view.findViewById(R.id.tvExpenseAmount)
    }

    // ==========================
    // ADAPTER CORE
    // ==========================
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_expense, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val expense = expenses[position]

        holder.tvTitle.text = expense.title
        holder.tvAmount.text = "Rs. ${"%.2f".format(expense.amount)}"
    }

    override fun getItemCount(): Int = expenses.size

    override fun getItemId(position: Int): Long {
        return expenses[position].id.toLong()
    }

    // ==========================
    // SWIPE HELPERS
    // ==========================
    fun getItem(position: Int): Expense? =
        if (position in expenses.indices) expenses[position] else null

    fun removeItem(position: Int) {
        if (position in expenses.indices) {
            expenses.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, expenses.size) // ✅ prevents UI glitch
        }
    }

    // ==========================
    // DATA REFRESH
    // ==========================
    fun setItems(newItems: List<Expense>) {
        expenses.clear()
        expenses.addAll(newItems)
        notifyDataSetChanged()
    }
}
