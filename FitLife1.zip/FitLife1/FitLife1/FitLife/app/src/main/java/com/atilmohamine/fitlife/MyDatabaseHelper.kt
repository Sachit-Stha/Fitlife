package com.atilmohamine.fitlife

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class MyDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "fitlife.db"
        const val DATABASE_VERSION = 3

        // USERS
        const val TABLE_USERS = "users"
        const val COL_USER_ID = "id"
        const val COL_USER_NAME = "name"
        const val COL_USER_EMAIL = "email"
        const val COL_USER_PASSWORD = "password"
        const val COL_USER_CREATED_AT = "created_at"

        // WORKOUTS
        const val TABLE_WORKOUTS = "workouts"
        const val COL_WORKOUT_ID = "id"
        const val COL_WORKOUT_TITLE = "title"
        const val COL_WORKOUT_SETS = "sets"
        const val COL_WORKOUT_REPS = "reps"
        const val COL_WORKOUT_NOTES = "notes"
        const val COL_WORKOUT_DONE = "is_done"
        const val COL_WORKOUT_USER_ID = "user_id"

        // EXPENSES
        const val TABLE_EXPENSES = "expenses"
        const val COL_EXPENSE_ID = "id"
        const val COL_EXPENSE_TITLE = "title"
        const val COL_EXPENSE_AMOUNT = "amount"
        const val COL_EXPENSE_USER_ID = "user_id"
    }

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL("""
            CREATE TABLE $TABLE_USERS (
                $COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_USER_NAME TEXT NOT NULL,
                $COL_USER_EMAIL TEXT UNIQUE NOT NULL,
                $COL_USER_PASSWORD TEXT NOT NULL,
                $COL_USER_CREATED_AT INTEGER
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_WORKOUTS (
                $COL_WORKOUT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_WORKOUT_TITLE TEXT,
                $COL_WORKOUT_SETS INTEGER,
                $COL_WORKOUT_REPS INTEGER,
                $COL_WORKOUT_NOTES TEXT,
                $COL_WORKOUT_DONE INTEGER,
                $COL_WORKOUT_USER_ID INTEGER
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_EXPENSES (
                $COL_EXPENSE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_EXPENSE_TITLE TEXT,
                $COL_EXPENSE_AMOUNT REAL,
                $COL_EXPENSE_USER_ID INTEGER
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_EXPENSES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WORKOUTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }

    // ==========================
    // USER FUNCTIONS
    // ==========================

    fun registerUser(name: String, email: String, password: String): Boolean {
        if (getUserIdByEmail(email) != null) return false

        val values = ContentValues().apply {
            put(COL_USER_NAME, name)
            put(COL_USER_EMAIL, email)
            put(COL_USER_PASSWORD, password)
            put(COL_USER_CREATED_AT, System.currentTimeMillis())
        }

        val db = writableDatabase
        val id = db.insert(TABLE_USERS, null, values)
        db.close()
        return id != -1L
    }

    fun loginUser(email: String, password: String): Int? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS,
            arrayOf(COL_USER_ID),
            "$COL_USER_EMAIL = ? AND $COL_USER_PASSWORD = ?",
            arrayOf(email, password),
            null, null, null
        )

        val userId = if (cursor.moveToFirst()) {
            cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID))
        } else null

        cursor.close()
        db.close()
        return userId
    }

    private fun getUserIdByEmail(email: String): Int? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS,
            arrayOf(COL_USER_ID),
            "$COL_USER_EMAIL = ?",
            arrayOf(email),
            null, null, null
        )

        val id = if (cursor.moveToFirst()) {
            cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID))
        } else null

        cursor.close()
        db.close()
        return id
    }

    fun getUserById(userId: Int): User? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS,
            null,
            "$COL_USER_ID = ?",
            arrayOf(userId.toString()),
            null, null, null
        )

        val user = if (cursor.moveToFirst()) {
            User(
                id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID)),
                name = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME)),
                email = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_EMAIL)),
                createdAt = cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_CREATED_AT))
            )
        } else null

        cursor.close()
        db.close()
        return user
    }

    // ==========================
    // WORKOUT FUNCTIONS
    // ==========================

    fun addWorkout(workout: Workout): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_WORKOUT_TITLE, workout.title)
            put(COL_WORKOUT_SETS, workout.sets)
            put(COL_WORKOUT_REPS, workout.reps)
            put(COL_WORKOUT_NOTES, workout.notes)
            put(COL_WORKOUT_DONE, if (workout.isDone) 1 else 0)
            put(COL_WORKOUT_USER_ID, workout.userId)
        }
        val id = db.insert(TABLE_WORKOUTS, null, values)
        db.close()
        return id
    }

    fun getWorkoutsForUser(userId: Int): List<Workout> {
        val list = mutableListOf<Workout>()
        val db = readableDatabase

        val cursor = db.query(
            TABLE_WORKOUTS,
            null,
            "$COL_WORKOUT_USER_ID = ?",
            arrayOf(userId.toString()),
            null, null,
            "$COL_WORKOUT_ID DESC"
        )

        if (cursor.moveToFirst()) {
            do {
                list.add(
                    Workout(
                        id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_WORKOUT_ID)),
                        title = cursor.getString(cursor.getColumnIndexOrThrow(COL_WORKOUT_TITLE)),
                        sets = cursor.getInt(cursor.getColumnIndexOrThrow(COL_WORKOUT_SETS)),
                        reps = cursor.getInt(cursor.getColumnIndexOrThrow(COL_WORKOUT_REPS)),
                        notes = cursor.getString(cursor.getColumnIndexOrThrow(COL_WORKOUT_NOTES)),
                        isDone = cursor.getInt(cursor.getColumnIndexOrThrow(COL_WORKOUT_DONE)) == 1,
                        userId = userId
                    )
                )
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return list
    }

    fun updateWorkoutDoneStatus(workoutId: Int, isDone: Boolean): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_WORKOUT_DONE, if (isDone) 1 else 0)
        }

        val rows = db.update(
            TABLE_WORKOUTS,
            values,
            "$COL_WORKOUT_ID = ?",
            arrayOf(workoutId.toString())
        )

        db.close()
        return rows
    }

    fun updateWorkout(workout: Workout): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_WORKOUT_TITLE, workout.title)
            put(COL_WORKOUT_SETS, workout.sets)
            put(COL_WORKOUT_REPS, workout.reps)
            put(COL_WORKOUT_NOTES, workout.notes)
            put(COL_WORKOUT_DONE, if (workout.isDone) 1 else 0)
        }

        val rows = db.update(
            TABLE_WORKOUTS,
            values,
            "$COL_WORKOUT_ID = ?",
            arrayOf(workout.id.toString())
        )

        db.close()
        return rows
    }

    fun deleteWorkout(workoutId: Int): Int {
        val db = writableDatabase
        val rows = db.delete(
            TABLE_WORKOUTS,
            "$COL_WORKOUT_ID = ?",
            arrayOf(workoutId.toString())
        )
        db.close()
        return rows
    }

    // ==========================
    // EXPENSE FUNCTIONS
    // ==========================

    fun addExpense(expense: Expense): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_EXPENSE_TITLE, expense.title)
            put(COL_EXPENSE_AMOUNT, expense.amount)
            put(COL_EXPENSE_USER_ID, expense.userId)
        }
        val id = db.insert(TABLE_EXPENSES, null, values)
        db.close()
        return id
    }

    fun getExpensesForUser(userId: Int): ArrayList<Expense> {
        val list = ArrayList<Expense>()
        val db = readableDatabase

        val cursor = db.query(
            TABLE_EXPENSES,
            null,
            "$COL_EXPENSE_USER_ID = ?",
            arrayOf(userId.toString()),
            null, null,
            "$COL_EXPENSE_ID DESC"
        )

        if (cursor.moveToFirst()) {
            do {
                list.add(
                    Expense(
                        id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_EXPENSE_ID)),
                        title = cursor.getString(cursor.getColumnIndexOrThrow(COL_EXPENSE_TITLE)),
                        amount = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_EXPENSE_AMOUNT)),
                        userId = userId
                    )
                )
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return list
    }

    fun deleteExpense(expenseId: Int): Int {
        val db = writableDatabase
        val rows = db.delete(
            TABLE_EXPENSES,
            "$COL_EXPENSE_ID = ?",
            arrayOf(expenseId.toString())
        )
        db.close()
        return rows
    }
}
