package com.atilmohamine.fitlife

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.imageview.ShapeableImageView
import java.text.SimpleDateFormat
import java.util.*

class ProfileActivity : AppCompatActivity() {

    private lateinit var session: SessionManager
    private lateinit var db: MyDatabaseHelper
    private lateinit var imgProfile: ShapeableImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        session = SessionManager(this)
        db = MyDatabaseHelper(this)

        val userId = session.getUserId()
        if (userId == null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        val tvUsername = findViewById<TextView>(R.id.tv_profile_username)
        val tvEmail = findViewById<TextView>(R.id.tv_profile_email)
        val tvUserId = findViewById<TextView>(R.id.tv_profile_userid)
        val tvJoined = findViewById<TextView>(R.id.tv_profile_joined)
        val btnLogout = findViewById<MaterialButton>(R.id.btn_profile_logout)

        val user = db.getUserById(userId)

        if (user != null) {
            tvUsername.text = user.name
            tvEmail.text = user.email
            tvUserId.text = "User ID: ${user.id}"
            tvJoined.text = "Joined: ${formatDate(user.createdAt)}"
        } else {
            tvUsername.text = "User"
            tvEmail.text = "-"
            tvUserId.text = "User ID: $userId"
            tvJoined.text = "Joined: N/A"
        }

        btnLogout.setOnClickListener {
            session.clearSession()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }


    // ====================================================
    // DATE FORMAT
    // ====================================================

    private fun formatDate(timestamp: Long?): String {
        if (timestamp == null) return "N/A"
        return SimpleDateFormat("MMMM yyyy", Locale.getDefault())
            .format(Date(timestamp))
    }
}
