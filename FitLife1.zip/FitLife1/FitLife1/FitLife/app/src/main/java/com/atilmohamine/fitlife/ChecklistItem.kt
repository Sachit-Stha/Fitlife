package com.atilmohamine.fitlife

data class ChecklistItem(
    val id: Int,
    val title: String,
    val sets: Int,
    val reps: Int,
    var isDone: Boolean
)
