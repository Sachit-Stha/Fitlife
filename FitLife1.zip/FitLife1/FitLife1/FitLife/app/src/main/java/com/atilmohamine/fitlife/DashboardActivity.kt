package com.atilmohamine.fitlife

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class DashboardActivity : AppCompatActivity() {

    private lateinit var session: SessionManager
    private lateinit var db: MyDatabaseHelper
    private var userId: Int = -1

    private lateinit var tvWelcome: TextView
    private lateinit var tvWorkoutCount: TextView
    private lateinit var tvCompletedCount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        session = SessionManager(this)

        // Secure session check
        val id = session.getUserId()
        if (id == null) {
            redirectToMain()
            return
        }

        userId = id
        db = MyDatabaseHelper(this)

        // UI references
        tvWelcome = findViewById(R.id.tv_welcome)
        tvWorkoutCount = findViewById(R.id.tv_workout_count)
        tvCompletedCount = findViewById(R.id.tv_completed_count)

        val cardWorkouts: MaterialCardView = findViewById(R.id.card_workouts)
        val cardChecklist: MaterialCardView = findViewById(R.id.card_checklist)
        val cardExpenses: MaterialCardView = findViewById(R.id.card_expenses)
        val cardProfile: MaterialCardView = findViewById(R.id.card_profile)
        val btnLogout: ImageButton = findViewById(R.id.btn_logout)

        // Navigation
        cardWorkouts.setOnClickListener {
            openScreen(WorkoutListActivity::class.java)
        }

        cardChecklist.setOnClickListener {
            openScreen(ChecklistActivity::class.java)
        }

        cardExpenses.setOnClickListener {
            openScreen(ExpensesActivity::class.java)
        }

        cardProfile.setOnClickListener {
            openScreen(ProfileActivity::class.java)
        }

        btnLogout.setOnClickListener {
            session.clearSession()
            redirectToMain()
        }
    }

    // ✅ THIS MAKES IT UPDATE EVERY TIME USER RETURNS
    override fun onResume() {
        super.onResume()
        loadDashboard()
    }

    private fun loadDashboard() {
        val username = session.getUsername() ?: "Athlete"
        tvWelcome.text = "Welcome back, $username 👋"

        val workouts = db.getWorkoutsForUser(userId)

        tvWorkoutCount.text = workouts.size.toString()

        val completedCount = workouts.count { it.isDone }
        tvCompletedCount.text = completedCount.toString()
    }

    private fun openScreen(target: Class<*>) {
        startActivity(Intent(this, target))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun redirectToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
