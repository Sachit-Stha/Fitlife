package com.atilmohamine.fitlife

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ExpensesActivity : AppCompatActivity() {

    private lateinit var etExpenseTitle: EditText
    private lateinit var etExpenseAmount: EditText
    private lateinit var btnAddExpense: Button
    private lateinit var rvExpenses: RecyclerView

    private lateinit var db: MyDatabaseHelper
    private lateinit var adapter: ExpenseAdapter
    private var userId: Int = -1
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expenses)

        // ---------------- SESSION ----------------
        session = SessionManager(this)
        val sid = session.getUserId()
        if (sid == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        userId = sid

        db = MyDatabaseHelper(this)

        // ---------------- UI ----------------
        etExpenseTitle = findViewById(R.id.etExpenseTitle)
        etExpenseAmount = findViewById(R.id.etExpenseAmount)
        btnAddExpense = findViewById(R.id.btnAddExpense)
        rvExpenses = findViewById(R.id.rvExpenses)

        rvExpenses.layoutManager = LinearLayoutManager(this)

        btnAddExpense.setOnClickListener { addExpense() }

        loadExpenses()
        attachSwipeToDelete()
    }

    // ---------------- ADD EXPENSE ----------------
    // ---------------- ADD EXPENSE ----------------
    private fun addExpense() {
        val title = etExpenseTitle.text.toString().trim()
        val amountText = etExpenseAmount.text.toString().trim()

        if (title.isEmpty() || amountText.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountText.toDoubleOrNull()
        if (amount == null) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show()
            return
        }

        val expense = Expense(title = title, amount = amount, userId = userId)
        val id = db.addExpense(expense)

        if (id != -1L) {
            Toast.makeText(this, "Expense added!", Toast.LENGTH_SHORT).show()

            // --- ADD THE LINE BELOW TO CLEAR THE TITLE ---
            etExpenseTitle.text.clear()
            // ---------------------------------------------

            etExpenseAmount.text.clear()
            loadExpenses()
        } else {
            Toast.makeText(this, "Failed to add expense", Toast.LENGTH_SHORT).show()
        }
    }


    // ---------------- LOAD EXPENSES ----------------
    private fun loadExpenses() {
        val expenses = db.getExpensesForUser(userId).toMutableList()
        adapter = ExpenseAdapter(expenses)
        rvExpenses.adapter = adapter
    }

    // ---------------- SWIPE TO DELETE ----------------
    private fun attachSwipeToDelete() {
        val swipeGesture = object : ItemTouchHelper.SimpleCallback(
            0,
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val expense = adapter.getItem(position) ?: return

                db.deleteExpense(expense.id)
                adapter.removeItem(position)

                Toast.makeText(
                    this@ExpensesActivity,
                    "Expense deleted",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        ItemTouchHelper(swipeGesture).attachToRecyclerView(rvExpenses)
    }
}
