package com.atilmohamine.fitlife

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddEditWorkoutActivity : AppCompatActivity() {

    private lateinit var db: MyDatabaseHelper

    private var workoutId: Int? = null
    private var userId: Int = -1

    private lateinit var etTitle: EditText
    private lateinit var etSets: EditText
    private lateinit var etReps: EditText
    private lateinit var etNotes: EditText
    private lateinit var cbDone: CheckBox
    private lateinit var btnSave: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit_workout)

        initDatabase()
        readIntent()
        initViews()
        setupScreenMode()
        setupSaveButton()
    }

    // --------------------------------------------------
    // INITIALIZATION
    // --------------------------------------------------

    private fun initDatabase() {
        db = MyDatabaseHelper(this)
    }

    private fun readIntent() {
        workoutId = intent.getIntExtra("workout_id", -1).takeIf { it != -1 }
        userId = intent.getIntExtra("user_id", -1)

        if (userId == -1) {
            Toast.makeText(this, "Invalid user session", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun initViews() {
        etTitle = findViewById(R.id.et_title)
        etSets = findViewById(R.id.et_sets)
        etReps = findViewById(R.id.et_reps)
        etNotes = findViewById(R.id.et_notes)
        cbDone = findViewById(R.id.cb_done)
        btnSave = findViewById(R.id.btn_save)
    }

    // --------------------------------------------------
    // SCREEN MODE (ADD / EDIT)
    // --------------------------------------------------

    private fun setupScreenMode() {
        if (workoutId != null) {
            title = "Edit Workout"
            loadExistingWorkout()
            btnSave.text = "Update Workout"
        } else {
            title = "Add Workout"
            btnSave.text = "Save Workout"
        }
    }

    private fun loadExistingWorkout() {
        val workout = db.getWorkoutsForUser(userId)
            .find { it.id == workoutId } ?: return

        etTitle.setText(workout.title)
        etSets.setText(workout.sets.toString())
        etReps.setText(workout.reps.toString())
        etNotes.setText(workout.notes ?: "")
        cbDone.isChecked = workout.isDone
    }

    // --------------------------------------------------
    // SAVE ACTION
    // --------------------------------------------------

    private fun setupSaveButton() {
        btnSave.setOnClickListener {
            saveWorkout()
        }
    }

    private fun saveWorkout() {
        val titleText = etTitle.text.toString().trim()
        val setsText = etSets.text.toString().trim()
        val repsText = etReps.text.toString().trim()
        val notesText = etNotes.text.toString().trim()
        val isDone = cbDone.isChecked

        if (titleText.isEmpty() || setsText.isEmpty() || repsText.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
            return
        }

        val sets = setsText.toIntOrNull()
        val reps = repsText.toIntOrNull()

        if (sets == null || reps == null || sets <= 0 || reps <= 0) {
            Toast.makeText(this, "Sets and reps must be valid numbers", Toast.LENGTH_SHORT).show()
            return
        }

        if (workoutId == null) {
            addWorkout(titleText, sets, reps, notesText, isDone)
        } else {
            updateWorkout(titleText, sets, reps, notesText, isDone)
        }

        finish()
    }

    // --------------------------------------------------
    // DATABASE OPERATIONS
    // --------------------------------------------------

    private fun addWorkout(
        title: String,
        sets: Int,
        reps: Int,
        notes: String,
        isDone: Boolean
    ) {
        val workout = Workout(
            title = title,
            sets = sets,
            reps = reps,
            notes = notes.ifEmpty { null },
            isDone = isDone,
            userId = userId
        )

        db.addWorkout(workout)
        Toast.makeText(this, "Workout added successfully", Toast.LENGTH_SHORT).show()
    }

    private fun updateWorkout(
        title: String,
        sets: Int,
        reps: Int,
        notes: String,
        isDone: Boolean
    ) {
        val workout = Workout(
            id = workoutId!!,
            title = title,
            sets = sets,
            reps = reps,
            notes = notes.ifEmpty { null },
            isDone = isDone,
            userId = userId
        )

        db.updateWorkout(workout)
        Toast.makeText(this, "Workout updated successfully", Toast.LENGTH_SHORT).show()
    }
}
