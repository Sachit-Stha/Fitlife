package com.atilmohamine.fitlife

data class Expense(
    val id: Int = 0,
    val title: String,
    val amount: Double,
    val userId: Int
)
