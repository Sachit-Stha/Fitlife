package com.atilmohamine.fitlife

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChecklistActivity : AppCompatActivity() {

    private lateinit var db: MyDatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ChecklistAdapter
    private var userId: Int = -1
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checklist)

        session = SessionManager(this)
        val sid = session.getUserId()
        if (sid == null) {
            Toast.makeText(this, "Please login", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        userId = sid

        db = MyDatabaseHelper(this)

        recyclerView = findViewById(R.id.rvChecklist)
        recyclerView.layoutManager = LinearLayoutManager(this)

        loadChecklist()
        setupSwipeGesture()
    }

    // --------------------------------------------------
    // LOAD CHECKLIST
    // --------------------------------------------------

    private fun loadChecklist() {
        val workouts = db.getWorkoutsForUser(userId)

        val checklistItems = workouts.map { w ->
            ChecklistItem(
                id = w.id,
                title = w.title,
                sets = w.sets,
                reps = w.reps,
                isDone = w.isDone
            )
        }.toMutableList()

        adapter = ChecklistAdapter(checklistItems) { item, isChecked ->
            val rows = db.updateWorkoutDoneStatus(item.id, isChecked)
            if (rows <= 0) {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show()
            }
        }

        recyclerView.adapter = adapter
    }

    // --------------------------------------------------
    // SWIPE TO COMPLETE / RESET
    // --------------------------------------------------

    private fun setupSwipeGesture() {
        val swipeGesture = object : ItemTouchHelper.SimpleCallback(
            0,
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val item = adapter.getItem(position) ?: return

                when (direction) {
                    ItemTouchHelper.RIGHT -> {
                        item.isDone = true
                        db.updateWorkoutDoneStatus(item.id, true)
                        Toast.makeText(
                            this@ChecklistActivity,
                            "Workout completed ✅",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    ItemTouchHelper.LEFT -> {
                        item.isDone = false
                        db.updateWorkoutDoneStatus(item.id, false)
                        Toast.makeText(
                            this@ChecklistActivity,
                            "Marked as pending ⏳",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                adapter.notifyItemChanged(position)
            }
        }

        ItemTouchHelper(swipeGesture).attachToRecyclerView(recyclerView)
    }
}
