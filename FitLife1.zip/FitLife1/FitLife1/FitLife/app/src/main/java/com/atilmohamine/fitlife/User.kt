package com.atilmohamine.fitlife

data class User(
    val id: Int,
    val name: String,
    val email: String,
    val createdAt: Long
)
