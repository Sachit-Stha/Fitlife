package com.atilmohamine.fitlife

data class Workout(
    val id: Int = 0,
    var title: String,
    var sets: Int,
    var reps: Int,
    var notes: String?,
    var isDone: Boolean,
    val userId: Int
)
